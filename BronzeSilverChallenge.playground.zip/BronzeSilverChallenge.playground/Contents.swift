import UIKit

var empty=""

if empty.startIndex == empty.endIndex
{
    print("string is empty")
}

if empty.isEmpty
{
    print("string is empty")
}

let hello = ("\u{0048}\u{0065}\u{006C}\u{006C}\u{006F}")

let hello2 = "Hello"

var isEqual = hello == hello2

