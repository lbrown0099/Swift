import UIKit

var loopTuple = (f: false, b: false)

for i in 1...100 {
    loopTuple = (f: i % 3 == 0, b: i % 5 == 0)
    switch loopTuple {
    case (f: true, b: true):
        print ("FIZZ BUZZ")
    case (f: true, b: false):
        print("FIZZ")
    case (f: false, b: true):
        print("BUZZ")
    default:
        print(i)
    }

}
