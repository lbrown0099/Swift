//
//  ViewController.swift
//  ElementQuiz
//
//  Created by Leigha  on 2/26/19.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageView: UIImageView!
    
    @IBOutlet weak var AnswerLabel: UILabel!
    
    let elementList = ["Carbon", "Gold", "Chlorine", "Sodium"]
   
    var currentElementIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        updateElement()
    }
    
    

    func updateElement() {
        AnswerLabel.text = "?"
        let elementName = elementList[currentElementIndex]
        let image = UIImage(named: elementName)
        ImageView.image = image
    }
    
    

    @IBAction func ShowAnswer(_ sender: Any) {
        AnswerLabel.text = elementList[currentElementIndex]
    }
    
    @IBAction func GotoNextElement(_ sender: Any) {
        currentElementIndex += 1
        if currentElementIndex >= elementList.count {
            currentElementIndex = 0
        }
        updateElement()
    }
    
}

