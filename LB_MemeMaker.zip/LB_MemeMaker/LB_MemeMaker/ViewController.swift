//
//  ViewController.swift
//  LB_MemeMaker
//
//  Created by Leigha  on 4/25/19.
//  Copyright © 2019 Web151. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var topCaptionSegmentedControl: UISegmentedControl!
    
    @IBOutlet weak var topCaptionLabel: UILabel!
    
    @IBOutlet weak var bottomCaptionLabel: UILabel!
    @IBOutlet weak var bottomCaptionSegmentControl: UISegmentedControl!
    
    var topChoices = [captionChoice] ()
    var bottomChoices = [captionChoice] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let coolChoice = captionChoice (emoji: "🕶" , caption: "You Know Whats Cool??!!!")
        
        
        let madChoice = captionChoice (emoji: "💥" , caption: "You Know What Makes Me Mad??!!!")
        
         let loveChoice = captionChoice (emoji: "💕" , caption: "You Know What I Love??!!!")
        
        topChoices = [coolChoice, madChoice, loveChoice]
        topCaptionSegmentedControl.removeAllSegments()
        
        for choice in topChoices {
            
            topCaptionSegmentedControl.insertSegment(withTitle: choice.emoji, at: topChoices.count, animated: false)
        }
        
        topCaptionSegmentedControl.selectedSegmentIndex = 0
        
        let catChoice = captionChoice(emoji: "🐈", caption: "Cats wearing hats")
        
        let dogChoice = captionChoice(emoji: "🐕", caption: "Dogs carrying logs")
        
        let monkeyChoice = captionChoice(emoji: "🐵", caption: "Monkeys getting funky")
        
        bottomChoices = [catChoice, dogChoice, monkeyChoice]
        bottomCaptionSegmentControl.removeAllSegments()
        for choice in bottomChoices {
            bottomCaptionSegmentControl.insertSegment(withTitle: choice.emoji, at: bottomChoices.count, animated: false)
        }
        
        bottomCaptionSegmentControl.selectedSegmentIndex = 0
        updateLables()
        
        }
        
        func updateLables() {
            let topIndex = topCaptionSegmentedControl.selectedSegmentIndex
            let bottomIndex = bottomCaptionSegmentControl.selectedSegmentIndex
            
            let topChoice = topChoices[topIndex]
            let bottomChoice = bottomChoices[bottomIndex]
            
            topCaptionLabel.text = topChoice.caption
            bottomCaptionLabel.text = bottomChoice.caption
            
    }
    
    
    @IBAction func choiceSelected(_ sender: Any) {
        updateLables()
    }
}

