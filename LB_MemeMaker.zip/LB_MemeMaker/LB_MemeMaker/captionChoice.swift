//
//  captionChoice.swift
//  LB_MemeMaker
//
//  Created by Leigha  on 4/25/19.
//  Copyright © 2019 Web151. All rights reserved.
//

import Foundation

struct captionChoice {
    let emoji: String
    let caption: String
}
