//
//  ViewController.swift
//  Proj02QuizApp_LB
//
//  Created by Leigha  on 4/30/19.
//  Copyright © 2019 Web151. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var Questionlabel: UILabel!
    
    @IBOutlet weak var button1: UIButton!
    
    @IBOutlet weak var button2: UIButton!
    
    @IBOutlet weak var button3: UIButton!
    
    @IBOutlet weak var button4: UIButton!
    
    @IBOutlet weak var Next: UILabel!
    
    @IBOutlet weak var LabelEnd: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Hide()
        Questions()
    }
    
    var CorrectAnswer = String()
    
    func Hide() {
    LabelEnd.isHidden = true
        Next.isHidden = true
    }
    
    func Unhide() {
        LabelEnd.isHidden = false
        Next.isHidden = false
    }
    
    @IBAction func bt1Action(_ sender: UIButton) {
        Unhide()
        if (CorrectAnswer == "1" ) {
            sender.flash()
            LabelEnd.text = "you are correct!"
        }
        else {
            sender.shake()
            LabelEnd.text = "you are wrong!"
        }
        
    }
    
    @IBAction func bt2Action(_ sender: UIButton) {
        Unhide()
        if (CorrectAnswer == "2" ) {
            sender.flash()
            LabelEnd.text = "you are correct!"
        }
        else {
            sender.shake()
            LabelEnd.text = "you are wrong!"
            
        }
        
    }
    
    @IBAction func bt3Action(_ sender: UIButton) {
        Unhide()
        if (CorrectAnswer == "3" ) {
            sender.flash()
            LabelEnd.text = "you are correct!"
        }
        else {
            sender.shake()
            LabelEnd.text = "you are wrong!"
            
        }
        
    }
    
    @IBAction func bt4Action(_ sender: UIButton) {
        Unhide()
        if (CorrectAnswer == "4" ) {
            sender.flash()
            LabelEnd.text = "you are correct!"
        }
        else {
            sender.shake()
            LabelEnd.text = "you are wrong!"
            
        }
        
    }
    
    
    @IBAction func next(_ sender: Any) {
        Questions()
        Hide()
    }
    
    
    func Questions() {
        var RandomNumber = arc4random() % 4
        RandomNumber += 1
        
        switch (RandomNumber) {
            
        case 1:
            Questionlabel.text = "what is 2 X 5?"
            button1.setTitle("2", for: UIControl.State.normal)
            button2.setTitle("4", for: UIControl.State.normal)
            button3.setTitle("8", for: UIControl.State.normal)
            button4.setTitle("10", for: UIControl.State.normal)
            CorrectAnswer = "4"
            
            break
        case 2:
            Questionlabel.text = "what is 2 X 7?"
            button1.setTitle("14", for: UIControl.State.normal)
            button2.setTitle("4", for: UIControl.State.normal)
            button3.setTitle("8", for: UIControl.State.normal)
            button4.setTitle("10", for: UIControl.State.normal)
            CorrectAnswer = "1"
            
            break
            
        case 3:
            Questionlabel.text = "what is 2 X 2?"
            button1.setTitle("4", for: UIControl.State.normal)
            button2.setTitle("7", for: UIControl.State.normal)
            button3.setTitle("8", for: UIControl.State.normal)
            button4.setTitle("10", for: UIControl.State.normal)
            CorrectAnswer = "1"
            break
            
        case 4:
            Questionlabel.text = "what is 2 X 9?"
            button1.setTitle("11", for: UIControl.State.normal)
            button2.setTitle("14", for: UIControl.State.normal)
            button3.setTitle("18", for: UIControl.State.normal)
            button4.setTitle("19", for: UIControl.State.normal)
            CorrectAnswer = "3"
            break
            
        default:
            break
            
            
            
        }
    }
    
    
    
    
 


}

