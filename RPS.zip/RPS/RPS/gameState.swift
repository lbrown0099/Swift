//
//  gameState.swift
//  RPS
//
//  Created by Leigha  on 3/18/19.
//  Copyright © 2019 Web151. All rights reserved.
//

import Foundation

enum gameState {
    case start, win, lose, draw
}
