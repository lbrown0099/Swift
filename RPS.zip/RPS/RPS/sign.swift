//
//  sign.swift
//  RPS
//
//  Created by Leigha  on 3/18/19.
//  Copyright © 2019 Web151. All rights reserved.
//

import Foundation
import GameplayKit


let randomChoice = GKRandomDistribution (lowestValue: 0, highestValue: 2)

func randomSign() -> Sign {
    let sign = randomChoice.nextInt()
    
    if sign == 0 {
        return .rock        
    }
    else if sign == 1 {
        return .paper
    }
    else {
        return .scissors
    }
}
enum Sign {
    case rock, paper, scissors
    
    var emoji: String{
        switch self {
        case .rock:
            return "👊"
        case .paper:
            return "✋"
        case .scissors:
            return "✌️"
        }//end switch self
    }//end var emoji
    func takeTurn(_ opponent: Sign) -> gameState {
        switch self {
        case .rock:
            switch opponent {
            case .rock:
                return gameState.draw
            case .paper:
                return gameState.lose
            case .scissors:
                return gameState.win
            }
        case .paper:
            switch opponent {
            case .rock:
                return gameState.win
            case .paper:
                return gameState.draw
            case .scissors:
                return gameState.lose
            }
        case .scissors:
            switch opponent {
            case .rock:
                return gameState.lose
            case .paper:
                return gameState.win
            case .scissors:
                return gameState.draw
            }//end case
       
          
        }//end switch
    
    } //end gamestate
}//end enum sign
    


