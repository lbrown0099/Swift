//
//  ViewController.swift
//  calculator
//
//  Created by Leigha  on 3/11/19.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//create and initialize variables
var numberOnScreen:Double = 0;
var previousNumber:Double = 0;
var performingMath = false
var operation = 0;

    //assign Var Label to UILabel
    @IBOutlet weak var Label: UILabel!
    
    //all numbers are linked to this function
    @IBAction func numbers(_ sender: UIButton)
   {
        //check if calculating numbers
        if performingMath == true
        {
            //get the number typed into screen
            Label.text = String(sender.tag-1)
            numberOnScreen = Double(Label.text!)!
            performingMath = false
            
        }
        else
        {
            Label.text = Label.text! + String(sender.tag-1)
            numberOnScreen = Double(Label.text!)!
        }
   }
    
    //provides add, subtract, multiply and devide abilities to buttons
    //if text is not null, neither C or = are pressed
    @IBAction func buttons(_ sender: UIButton)
    {
        if Label.text != "" && sender.tag != 11 && sender.tag != 16
        {
            previousNumber = Double(Label.text!)!
            
            if sender.tag == 12 //devide button
            {
                Label.text = "/";
                
            }
            else if sender.tag == 13 //multiply button
            {
                Label.text = "X";
                
            }
            else if sender.tag == 14 //subtract button
            {
                Label.text = "-";
                
            }
            else if sender.tag == 15 //add button
            {
                Label.text = "+";
            }
            
            operation = sender.tag
            performingMath = true;
        
        }
            //if equal sign is pressed
        else if sender.tag == 16
        {
           if operation == 12
            {
                 Label.text = String(previousNumber / numberOnScreen)
                
           }
            else if operation == 13
            {
                 Label.text = String(previousNumber * numberOnScreen)
                
           }
            else if operation == 14
            {
                 Label.text = String(previousNumber - numberOnScreen)
                
           }
            else if operation == 15
            {
                Label.text = String(previousNumber + numberOnScreen)
            }
            
        }
        //if the C button is pressed, the window is cleared
       else if sender.tag == 11
        {
            Label.text = ""
            previousNumber = 0;
            numberOnScreen = 0;
            operation = 0;
        }
      
    }
    
    
    
   override func viewDidLoad() {
       super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   }


}

