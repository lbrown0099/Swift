import UIKit

// silver challenge
let NC = ["County1": [10001, 10002, 10003, 10004, 10005],
                  "County2": [20001, 20002, 20003, 20004, 20005],
                  "County3": [30100, 30102, 30103, 30104, 30105]]

var zipCodes: [Int] = []
for codes in NC.values {
    zipCodes += codes
}

print("North Caroline has the following zipcodes: \(zipCodes)")
