import UIKit

//Bronze
var toDoList = ["Take out the garbage", "Pay bills", "Cross off finished items"]
toDoList.isEmpty // false
//or
toDoList.count // 3

//Silver
var reversedArray = [String]()
for item in toDoList {
    reversedArray.insert(item, at: 0)
}
print(reversedArray) // ["Cross off finished items", "Pay bills", "Take out the garbage"]

// Silver (better)
toDoList.reverse()
print(toDoList) // ["Cross off finished items", "Pay bills", "Take out the garbage"]
