
import Foundation

class Zombie: Monster {
    var walksWithLimp = true
    
    final override func terrorizeTown() {
        if let enoughPeople = town?.population {
            if enoughPeople > 0 {
                town?.changePopulation(-10)
            }
        }
        super.terrorizeTown()
    }
    
    func changeName(name: String, walksWithLimp: Bool){
        self.name = name
        self.walksWithLimp = walksWithLimp
    }
}
